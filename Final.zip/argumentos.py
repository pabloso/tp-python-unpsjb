# -*- coding: utf-8 -*-
#==============================================================================
import os
import argparse

#==============================================================================

#==============================================================================
def obtencion_de_argumentos():
    'Funcion de parseo de de linea de comandos'
#==============================================================================
    parser = argparse.ArgumentParser(description='''Parsea linea de comandos''')
    
    parser.add_argument('--template','-t',dest='temp', metavar='<NombredeArchivo>', type=str, help='Ruta al template')
    parser.add_argument('--csv','-c',dest='csv', metavar='<NombredeArchivo>', type=str, help='Ruta al csv')
    parser.add_argument('--documento','-d',dest='txt', metavar='<NombredeArchivo>', type=str, help='Ruta al documento destino')
    return parser.parse_args()


def main():
    args = obtencion_de_argumentos()
    if os.path.exists(args.temp) and os.path.isfile(args.temp):
        if os.path.exists(args.csv) and os.path.isfile(args.csv):
            try:
                #duro
        #print args.temp
    return 0


if __name__ == '__main__':
    main()